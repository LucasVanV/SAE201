public class Application {
	public static void main(String[] args) {
		Monde m = new Monde(1);
		m.creer_monde();
		m.afficher_console(1);
	}
}
